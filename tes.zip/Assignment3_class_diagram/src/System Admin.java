import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("a18e25d0-426f-4b08-8759-471644b38d2f")
public class System Admin extends Person {
    @objid ("4d9a02f0-d87e-4656-a65f-6a2769678151")
    private int AdminID;

    @objid ("2ee0ec32-0957-4d9a-b2bb-dcf5bf0ee69a")
    private Citizen[] Citizens;

    @objid ("2097ab76-4a8c-45e5-8d34-f78fa6631844")
    private Medical Staff[] Medical_Staffs;

    @objid ("0060cbda-f614-45b9-90f3-e09e58016fd7")
    private Doctor[] Doctors;

    @objid ("de1e2159-52fe-426b-a5a7-1a01b0a1eac5")
    private Nurse[] Nurses;

    @objid ("a2394e3c-2cb8-4a9a-933f-d42c7f6f3d10")
    public List<Medical Staff>  = new ArrayList<Medical Staff> ();

    @objid ("a662c1c4-d9e0-4950-9c5a-04e8c2ff10bb")
    public List<Citizen>  = new ArrayList<Citizen> ();

    @objid ("fd6e3b70-f252-48d9-8440-ee120e637e7f")
    public void Add_Citizen(Citizen citizen) {
    }

    @objid ("9a9c65fa-6619-4fd9-bdf7-7e0933b33701")
    public void Add_Medical_Staff(Medical Staff medical staff) {
    }

    @objid ("2dfc467a-dc30-4b21-a8f6-aef0ee7a0930")
    public void Add_doctor(Doctor doctor) {
    }

    @objid ("d8540c93-fabe-4e8c-a8dc-bd1fe9dc2a28")
    public void Add_nurse(Nurse nurse) {
    }

    @objid ("ad9a56a9-4fc4-4c0d-a9b3-334b503d2d6c")
    public void Delete_Citizen(Citizen citizen) {
    }

    @objid ("7a22a267-edcc-4bd3-b2f1-0dac164392ab")
    public void Delete_Medical_Staff(Medical Staff medical staff) {
    }

    @objid ("d8ce70a7-94b3-4147-a51d-7ab16a9479ad")
    public void Delete_nurse(Nurse nurse) {
    }

    @objid ("9869fa4f-3719-46e2-8c90-16de759262a7")
    public void Delete_doctor(Doctor doctor) {
    }

    @objid ("05c101b5-b647-4aa5-81f2-9562dc2888ff")
    public void Get_Medical_Staff(Medical Staff medical staff) {
    }

    @objid ("769e4112-c132-4f5c-a159-324bd9eb9506")
    public void Get_doctor(Doctor doctor) {
    }

    @objid ("cf22be4e-a720-4226-9a57-e562329dc269")
    public System Admin(int admin_id) {
    }

}
