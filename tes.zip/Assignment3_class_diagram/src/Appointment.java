import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("d8bfbcfe-3f76-4508-8487-db1e265d05fc")
public class Appointment {
    @objid ("bc3a1bdb-6cad-4917-bd02-ea87f7a24b72")
    private Date Date;

    @objid ("36640c60-c4b7-47fd-b582-902ad14c1754")
    private Citizen citizen;

    @objid ("864957e7-1742-4b72-b0b8-b08cea45cd6d")
    private String hospital;

    @objid ("1b181ee2-c846-4764-837a-e4dd1e472dea")
    private int AppointmentID;

    @objid ("d5f540c9-8d7c-47d5-9ab9-2bc9825dbab8")
    private Nurse nurse;

    @objid ("ed7180a1-f830-4fb0-8660-b682e6a46ae9")
    public Appointment(Date date, Citizen citizen, String hospital, Nurse nurse) {
    }

    @objid ("1327e1f9-238c-4734-9de9-7bbb14af48c5")
    public Date Get_date() {
    }

    @objid ("7ae0b8c7-9b59-43a8-accc-342f6961e7b5")
    public void Get_Citizen(Citizen citizen) {
    }

    @objid ("460a4707-f4bb-4ebc-87b1-c8a9816ccaf4")
    public void Get_nurse(Nurse nurse) {
    }

}
