import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("7ebd29ef-3518-422c-9b57-016dd510538d")
public class Citizen extends Person {
    @objid ("7a661e64-628a-46f9-91ce-fbc3ccfa6260")
    private String AFM;

    @objid ("11227460-d2cf-47b7-89f7-e90a62383dd2")
    private String password;

    @objid ("846a18b9-1635-4246-8171-d435c27df686")
    private int UserID;

    @objid ("1c430c71-4f35-4a4f-8297-ba69e06330e9")
    private boolean Vaccinated;

    @objid ("0c400cd0-ed75-4164-b0ee-e1fd389c72a1")
    public Appointment appointment;

    @objid ("201c1ae8-4cde-42af-a68e-b78d4f07ad00")
    private String First name;

    @objid ("a9de0c5a-5811-494b-941c-e67ce5eaf7bc")
    private String Fathers name;

    @objid ("862ba04f-b458-4a76-b923-1574f5f66a7c")
    private String Last name;

    @objid ("01fe9678-0598-4fa6-b3cd-2c59fe5be912")
    private int Phone_number;

    @objid ("669de5a3-757d-4196-9d82-925da08ef488")
    public Date Get_born_date () {
    }

    @objid ("309b0638-2ae8-41af-b384-6baa941def01")
    public String Get_full_name() {
    }

    @objid ("4297f968-12e3-4a10-b24b-25449a0ead6c")
    public int Get_userID() {
    }

    @objid ("6c1bc698-a6d3-4bee-b76c-3cbae30890c8")
    public String Get_AFM() {
    }

    @objid ("2cea4da9-60a9-4aec-aa1e-08a70e813d01")
    public void Set_new_password(int old_password) {
    }

    @objid ("ef26bfed-2e7e-4cce-ae40-ee7463d35d1a")
    public Citizen(String first_name, String last_name, Date born_date, String AFM) {
    }

    @objid ("5cb998d1-4eda-4b41-91d6-5b98b53c4594")
    public void Set_phone(int number) {
    }

    @objid ("b7a7fa29-016e-42de-8f79-f168e5b7d38d")
    public void Set_father(String father) {
    }

    @objid ("fc52a640-4b2e-4a3a-9f53-c1a35bd731bd")
    public boolean IsVaccinated() {
    }

    @objid ("5c8fb99b-66db-47e2-81cf-49669e1254e6")
    public void Set_Vaccinated(boolean vaccinated) {
    }

    @objid ("12e58829-cd13-48cf-b250-0ec06d85d667")
    public void Set_appointment(Appointment appointment) {
    }

    @objid ("27ba9859-9482-4f54-a502-a0755b15391b")
    public void Cancel_appointment(Appointment appointment) {
    }

    @objid ("dd882b14-a8d1-43c8-8958-9ecd4f8fc250")
    public Appointment Get_Appointment() {
    }

    @objid ("ff479514-ad62-4113-b02e-d991e4e11dc3")
    String getFirst name() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.First name;
    }

    @objid ("9d6b0483-1c11-40fa-99fa-3d281fc50045")
    void setFirst name(String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.First name = value;
    }

    @objid ("aea8421c-66c2-4f4e-9541-c44310ebad00")
    String getFathers name() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.Fathers name;
    }

    @objid ("0072eb80-675e-4d8c-9f5c-d097bcbfbfb2")
    void setFathers name(String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.Fathers name = value;
    }

    @objid ("2f0a7c7f-92c2-495e-96a1-d9116fb64019")
    String getLast name() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.Last name;
    }

    @objid ("4b6b0026-75d2-4cec-8da4-97ede34496eb")
    void setLast name(String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.Last name = value;
    }

    @objid ("4c81af5f-4ab6-4435-bb42-3770f3f700b0")
    int getPhone_number() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.Phone_number;
    }

    @objid ("93e99332-6a5c-4e7e-8951-4e09cd42f2d4")
    void setPhone_number(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.Phone_number = value;
    }

}
