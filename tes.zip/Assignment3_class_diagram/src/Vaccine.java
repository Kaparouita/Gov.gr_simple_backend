import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("7b4f3599-4f5e-49fc-8bd3-70d62d4eb621")
public class Vaccine {
    @objid ("f4f015c2-41fe-4d5d-9ad7-7348a8a8bb78")
    private String Name;

    @objid ("05c47517-2776-4771-867f-57e4a3494817")
    private Citizen Person;

    @objid ("0317c572-2658-4fbb-9408-f5c9f1ececd4")
    private Nurse Nurse;

    @objid ("d79cd9b1-ad97-4950-8a4d-9d4cdaedd7cb")
    private Date Date;

    @objid ("9e2aca3e-dd9b-4dd3-ad89-ea5afbd0e62b")
    public void Vaccinate(Citizen citizen, Nurse nurse, Date date) {
    }

    @objid ("7c6b6582-d7c3-4740-8a07-8235c6d19f29")
    public Vaccine(String vaccine_name) {
    }

    @objid ("c46060de-74e2-4e81-91fc-e050550450b6")
    public String Get_name() {
    }

    @objid ("055c7df8-b52a-489d-8e29-8b9ff0442de9")
    public Citizen Get_Person() {
    }

    @objid ("d3128075-7388-4714-a966-a852b8843838")
    public Nurse Get_Nurse() {
    }

    @objid ("50dc5d5a-13b1-4dec-9c0f-d61845071080")
    public Date Get_date() {
    }

}
