import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("98e574d7-f812-4c83-8f55-89fadfd97d28")
public abstract class Person {
    @objid ("21c136a6-217d-4145-b8c0-1f4bc7fdff12")
    private String First name;

    @objid ("3b95d28a-c1a6-48aa-851b-f7ab20fab337")
    private String Fathers name;

    @objid ("f7e37427-aece-4ed9-9dee-3dd39a7d903b")
    private String Last name;

    @objid ("a25a127b-1620-4c6a-97b1-1248ea260d69")
    private int Phone_number;

    @objid ("e36d807f-7ef8-4f45-8ee3-82c6c469a4c9")
    private Date Born_date;

    @objid ("df8b1798-b5f1-4cd9-a4d1-47634ae51a48")
    String getFirst name() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.First name;
    }

    @objid ("a7f29bae-c466-4fe2-94e4-202a2e10b249")
    void setFirst name(String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.First name = value;
    }

    @objid ("eb4d63dc-023c-4f99-aae3-f0b9592dbcb4")
    String getFathers name() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.Fathers name;
    }

    @objid ("34df6217-0bcd-4359-a058-4ca58534d00c")
    void setFathers name(String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.Fathers name = value;
    }

    @objid ("23d76390-bd13-4aa9-b430-2f84f4506c69")
    String getLast name() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.Last name;
    }

    @objid ("fc214a43-0795-4c38-9ef9-a5f672dc8253")
    void setLast name(String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.Last name = value;
    }

    @objid ("3b3a224c-a0c0-43e1-abde-ed82f00f6e41")
    int getPhone_number() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.Phone_number;
    }

    @objid ("6caa699b-fec5-4db5-a919-3824f3a61ed3")
    void setPhone_number(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.Phone_number = value;
    }

    @objid ("b2f52fb2-ebff-4709-bbd6-b8cc0a1d3a57")
    Date getBorn_date() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.Born_date;
    }

    @objid ("33c9fcf8-4743-4931-a7d6-f110fc1730c2")
    void setBorn_date(Date value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.Born_date = value;
    }

}
