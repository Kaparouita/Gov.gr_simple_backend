import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("fec77883-d8f3-415e-9749-9eeecb9cb265")
public abstract class Medical Staff extends Person {
    @objid ("7c185a6a-cdc9-4725-a93c-2c191ea7fcd5")
    private String Hospital_name;

    @objid ("099ed772-685b-48a1-aeb2-34633927f91b")
    private String Department_name;

    @objid ("f64071e2-9d27-44fb-b2ed-4276f1ff5721")
    private String Intership;

    @objid ("6cf1c75b-03a5-4d23-bb44-13d7d8b403aa")
    private Appointment[] MS_Appointments;

    @objid ("818d5b3d-fa78-4bc0-b6c2-84a5ac9fe1aa")
    public String Get_hospital name() {
    }

    @objid ("8c23bf54-e9c7-46b1-8bf4-1ca6569282b8")
    public String Get_department_name() {
    }

    @objid ("0d5da0ec-d84a-44a5-8fb6-61873576cca2")
    String getIntership() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.Intership;
    }

    @objid ("d9744c68-2df9-4c62-ae8b-62608d00e23c")
    void setIntership(String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.Intership = value;
    }

    @objid ("03e1b669-8e2a-4327-85c0-5ea6082e0a55")
    Appointment[] getMS_Appointments() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.MS_Appointments;
    }

    @objid ("c76b02db-1035-425b-87f8-b652b53a4733")
    void setMS_Appointments(Appointment[] value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.MS_Appointments = value;
    }

}
