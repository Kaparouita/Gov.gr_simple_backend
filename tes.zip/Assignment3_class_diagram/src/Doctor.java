import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("05f7e106-af77-4b9e-b684-e5054992513e")
public class Doctor extends Medical Staff {
    @objid ("7ebbf4c2-6d3a-4073-9c3b-c4b4d2b55521")
    private String Name;

    @objid ("2d3f3bcd-c5e4-4693-a699-a83943d9a310")
    private int DoctorID;

    @objid ("13c10589-884b-4f81-82cc-2ed3ea4c706a")
    private Medical Staff Department;

    @objid ("f3574d31-4cd3-4e51-b397-3a5f9fbfdb51")
    public String Get_name() {
    }

    @objid ("d70fdf93-7340-40ff-a162-d88362f4b056")
    public Date Get_born_date() {
    }

    @objid ("d0ae29e1-ece1-4d39-94ca-f862ad270909")
    public String Get_intership() {
    }

    @objid ("35c398f9-4652-482f-a18a-4f467bdcf0c2")
    public int Get_docID() {
    }

    @objid ("908c121f-d715-4336-811c-436f1cfa81ee")
    public Medical Staff Get_medical_staff() {
    }

    @objid ("eac473ee-09ef-471a-b4e3-bc0ab22940d5")
    public Doctor(String name, Date born_date) {
    }

    @objid ("ae80b367-ca26-4c3a-8c4b-d26fb09d51c4")
    public void Set_medical_staff(Medical Staff p1) {
    }

    @objid ("f662e9ea-5771-4f55-bd53-ba6c7c66f5f7")
    public void Set_intership(String p1) {
    }

}
