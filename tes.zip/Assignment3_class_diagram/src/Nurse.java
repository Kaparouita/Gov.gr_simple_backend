import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("728d6919-4cda-4a33-8f88-f59ce937ef9e")
public class Nurse extends Medical Staff {
    @objid ("8c938647-e1a9-4d6c-8fb9-1e0b5516d0ae")
    private String Name;

    @objid ("e5faa609-4ab7-466f-9072-763a60bc15d6")
    private Date Born_date;

    @objid ("9d5011a9-bad3-4961-972c-8242887b8ee3")
    private int nurseID;

    @objid ("fbb8a5fc-eb5f-497a-b12f-2a1f2451e438")
    private Doctor Working_for;

    @objid ("e785f37a-ce02-4f5d-9f24-8ac065bd27d5")
    public String Get_name() {
    }

    @objid ("71b00c4d-f46b-4cab-9580-ffc1b6b96d80")
    public Date Get_born_date() {
    }

    @objid ("5726935e-02ea-4b29-b6d2-5fb714edc16e")
    public int Get_nurseID() {
    }

    @objid ("78d5f218-39fd-4e31-afbf-681e3af3b78d")
    public Medical Staff Get_medical_staff() {
    }

    @objid ("f559b9e1-dfb8-441d-b7ef-957c1138a963")
    public Nurse(String name, Date born_date) {
    }

    @objid ("2f75eafe-ffd7-4a76-84d0-a0fd08f1f4a4")
    public void Set_medical_staff(Medical Staff p1) {
    }

    @objid ("f58e5d08-1e81-4c89-b123-7accd1aad0f4")
    public Doctor Get_working_for() {
    }

    @objid ("aa99f092-5b35-44db-a4c5-e37f5a4e5a84")
    public void Set_working_for(Doctor p1) {
    }

    @objid ("4e6c383f-93c9-43ff-9027-ef5a9d04c3ab")
    public void Vaccinate_citizen(Citizen citizen, Vaccine vaccine) {
    }

}
